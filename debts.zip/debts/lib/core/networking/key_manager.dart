class KeyManager {
  static const debtCollectionKey = 'debts';
}
